Ryu
=====

2D Game using Slick2D library

It's a side-scrolling beat 'em up video game with Ryu from Street Fighter as the main character. 

v0.1

-The base of the game is done.Simple menu with options and credits, main map, and Mana and HP for the main character.

-Ryu and his skills is done.
